﻿Imports MySql.Data.MySqlClient
'Melanie Galaretto
Public Class frmRegistro

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click

        If txtNombre.Text = "" Or txtPass.Text = "" Or txtPass2.Text = "" Then
            MsgBox("Ha ocurrido un error, porfavor llena los campos correspondientes", MsgBoxStyle.Critical + vbOK)

        ElseIf txtPass.Text <> txtPass2.Text Then
            MsgBox("Las contraseñas no coinciden", MsgBoxStyle.Critical)

        ElseIf ExistenciaUsuario2(txtNombre.Text) = True Then

            MsgBox("Este usuario ya existe", MsgBoxStyle.Critical)

        Else
            Registro(txtNombre.Text, txtPass.Text)
            Me.Hide()
        End If





    End Sub
    Function ExistenciaUsuario2(ByVal nombre As String) As Boolean
        Dim Conexion As New MySqlConnection
        Dim DataAdapter As MySqlDataAdapter = New MySqlDataAdapter
        Dim oDataSet As New DataSet
        Dim cmd As MySqlCommand = New MySqlCommand
        Dim ver As Boolean = False

        Try
            Conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"
            Conexion.Open()
            cmd.Connection = Conexion

            cmd.CommandText = "SELECT idUsuario, nombre, pass, activo FROM  usuarios WHERE nombre=@nombre"
            cmd.Parameters.AddWithValue("@nombre", nombre)
            DataAdapter.SelectCommand = cmd

            oDataSet.Reset()
            DataAdapter.Fill(oDataSet, "Tabla")

            If (oDataSet.Tables("Tabla").Rows.Count() = 1) Then
                ver = True
            Else
                ver = False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return ver


    End Function

    Function Registro(ByVal nombre As String, ByVal contraseña As String) As Boolean
        Dim conexion As New MySqlConnection
        Dim adaptador As New MySqlDataAdapter
        Dim cmd As New MySqlCommand
        Dim ds As New DataSet
        Dim ret As Boolean
        Dim OK As Byte
        OK = MsgBox("¿Desea terminar el registro?", MsgBoxStyle.Information + vbYesNo)

        If OK = vbYes Then
            Try
                conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"
                conexion.Open()
                cmd.Connection = conexion
                cmd.CommandText = "INSERT INTO usuarios(nombre, pass, idRol, activo) VALUES (@nombre, @pass, @idRol, @activo)"
                cmd.Prepare()

                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@nombre", nombre)
                cmd.Parameters.AddWithValue("@pass", contraseña)
                cmd.Parameters.AddWithValue("@idRol", 3)
                cmd.Parameters.AddWithValue("@activo", 0)
                cmd.ExecuteNonQuery()
                conexion.Close()


            Catch ex As Exception

            End Try
        End If
        Return ret = True


    End Function
    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        End

    End Sub
End Class