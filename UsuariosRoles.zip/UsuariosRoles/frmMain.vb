﻿Imports MySql.Data.MySqlClient
'Melanie Galaretto
Public Class frmMain
    Sub ActualizarSelect()
        Dim conexion As MySqlConnection = New MySqlConnection
        Dim cmd As New MySqlCommand
        Dim ds As DataSet = New DataSet
        Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter

        conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"

        Try
            conexion.Open()
            cmd.Connection = conexion

            cmd.CommandText = "SELECT nombre, idRol, activo FROM usuarios ORDER BY nombre ASC"
            adaptador.SelectCommand = cmd
            adaptador.Fill(ds, "Tabla")
            grdUsuarios.DataSource = ds
            grdUsuarios.DataMember = "Tabla"

            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim nombre1 As String
        nombre1 = frmLogin.txtUsuario.Text
        lbBienvenido.Text = " Bienvenido  " + nombre1

        ActualizarSelect()
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

    Private Sub btnActivar_Click(sender As Object, e As EventArgs) Handles btnActivar.Click
        Dim m As Boolean
        Dim nombre As String
        If (grdUsuarios.SelectedRows.Count > 0) Then
            m = grdUsuarios.Item("Activo", grdUsuarios.SelectedRows(0).Index).Value
            nombre = grdUsuarios.Item("Nombre", grdUsuarios.SelectedRows(0).Index).Value
            If m = False Then
                TrueFalse(m, nombre)
                actualizador()
            End If
        End If
    End Sub

    Private Sub btnDesactivar_Click(sender As Object, e As EventArgs) Handles btnDesactivar.Click
        Dim m As Boolean
        Dim nombre As String
        If (grdUsuarios.SelectedRows.Count > 0) Then
            m = grdUsuarios.Item("Activo", grdUsuarios.SelectedRows(0).Index).Value
            nombre = grdUsuarios.Item("Nombre", grdUsuarios.SelectedRows(0).Index).Value
            If m = True Then
                TrueFalse(m, nombre)
                actualizador()
            End If
        End If

    End Sub

    Function TrueFalse(ByVal a As Boolean, ByVal nombre As String) As Boolean
        Dim conexion As MySqlConnection = New MySqlConnection
        Dim cmd As New MySqlCommand
        Dim ds As DataSet = New DataSet
        Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter
        Dim z As Boolean
        Dim numero As Integer = 0

        If a = False Then
            'Numero 1 era para decirle a activo que sea verdadero y 0 lo contrario
            numero = 1
            'La z retorna si es verdadero o falso
            z = False
        Else
            numero = 0
            z = True
        End If

        Try
            conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"
            conexion.Open()
            cmd.Connection = conexion
            cmd.CommandText = "UPDATE usuarios SET activo=@activo WHERE nombre=@nombre"
            cmd.Prepare()
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@activo", numero)
            cmd.Parameters.AddWithValue("@nombre", nombre)
            cmd.ExecuteNonQuery()

            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return z


    End Function

    Public Sub actualizador()
        Dim conexion As New MySqlConnection
        Dim DataAdapter As MySqlDataAdapter
        Dim oDataSet As New DataSet
        Dim e As String

        Try
            conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"
            e = "SELECT  idUsuario, nombre, pass, activo FROM usuarios ORDER BY Nombre ASC"
            conexion.Open()
            DataAdapter = New MySqlDataAdapter(e, conexion)
            DataAdapter.Fill(oDataSet, "Tabla")
            grdUsuarios.DataSource = oDataSet
            grdUsuarios.DataMember = "Tabla"
            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub btnCambiar_Click(sender As Object, e As EventArgs) Handles btnCambiar.Click
        Dim pass, pass2, nombre As String
        pass = grdUsuarios.Item("pass", grdUsuarios.SelectedRows(0).Index).Value
        pass2 = InputBox("Ingrese la nueva contraseña", "Ingrese contraseña nueva", pass, 100, 0)
        nombre = grdUsuarios.Item("nombre", grdUsuarios.SelectedRows(0).Index).Value

        If passNueva(nombre, pass2) Then
            MsgBox("Se ha cambiado su contraseña", MsgBoxStyle.Information)
        Else
            MsgBox("No se logro cambiar", MsgBoxStyle.Critical)

        End If
        actualizador()
    End Sub

    Function passNueva(ByVal n As String, ByVal pass As String) As Boolean
        Dim conexion As MySqlConnection = New MySqlConnection
        Dim cmd As New MySqlCommand
        Dim ds As DataSet = New DataSet
        Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter
        Dim b As Boolean

        Try
            conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"
            conexion.Open()
            cmd.Connection = conexion
            cmd.CommandText = "UPDATE usuarios SET pass=@pass WHERE nombre=@nombre"
            cmd.Prepare()

            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("pass", pass)
            cmd.Parameters.AddWithValue("nombre", n)
            cmd.ExecuteNonQuery()

            conexion.Close()
            b = True

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
            b = False
        End Try
        Return b

    End Function
End Class