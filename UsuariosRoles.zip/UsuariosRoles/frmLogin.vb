﻿Imports MySql.Data.MySqlClient
'Melanie Galaretto
Public Class frmLogin
    Dim conexion As New MySqlConnection
    Dim DataAdapter As New MySqlDataAdapter
    Dim oDataSet As New DataSet
    Dim Sql, Sql2 As String
    Dim ver As Boolean = False
    Dim cmd As New MySqlCommand


    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        '0 = Administrador
        '1 = Operador
        '2 = Invitado

        If ExistenciaUsuario(txtUsuario.Text, txtContraseña.Text) = 0 Or ExistenciaUsuario(txtUsuario.Text, txtContraseña.Text) = 1 Then
            frmMain.ShowDialog()
            Me.Hide()

        ElseIf ExistenciaUsuario(txtUsuario.Text, txtContraseña.Text) = 2 Then
            MsgBox("Usuario Invitado")
            'UsuariosInvitados.ShowDialog()
        Else
            MsgBox("Datos ingresados incorrectamente", MsgBoxStyle.Critical)

        End If
        txtUsuario.Text.DefaultIfEmpty
        txtContraseña.Text.DefaultIfEmpty

    End Sub

    Private Sub btnRegistrarse_Click(sender As Object, e As EventArgs) Handles btnRegistrarse.Click
        frmRegistro.Show()

    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Function ExistenciaUsuario(ByVal usuario As String, ByVal pass As String) As Integer
        Dim ver As Integer

        Try
            Conexion.ConnectionString = "server=localhost; database=usuarios_roles;Uid=root;Pwd=;"
            Sql = "SELECT * FROM usuarios WHERE nombre='" & usuario & "' AND pass='" & pass & "' AND activo = 1"

            Conexion.Open()
            DataAdapter = New MySqlDataAdapter(Sql, Conexion)
            oDataSet.Clear()
            DataAdapter.Fill(oDataSet, "usuarios")


            If (oDataSet.Tables("usuarios").Rows.Count() = 1) Then
                'Si el usuario si existe:
                Dim num As Integer
                'Verificar que rol tiene
                num = oDataSet.Tables("usuarios").Rows(0).Item("idRol")

                If num = 1 Then
                    ver = 0
                    'El usuario es administrador
                ElseIf num = 2 Then
                    'MainMenu.gbA.Enabled = False
                    ver = 1
                    'El usuario es operador

                ElseIf num = 3 Then
                    'Es invitado
                    ver = 2
                End If

            Else
                'El usuario no existe
                ver = 3

            End If
            Conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

        Return ver
    End Function
End Class
